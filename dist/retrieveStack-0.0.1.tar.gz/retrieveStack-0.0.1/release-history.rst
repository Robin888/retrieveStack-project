Release and Version History
===========================

0.0.2 (TODO)
~~~~~~~~~~~~~~~~~~
**Features and Improvements**

**Minor Improvements**

**Bugfixes**

**Miscellaneous**


0.0.1 (2016-01-01)
~~~~~~~~~~~~~~~~~~
- First release